﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GeneralController : MonoBehaviour {

	public float perspectiveZoomSpeed = 0.5f;        // The rate of change of the field of view in perspective mode.
	public float orthoZoomSpeed = 0.5f;        // The rate of change of the orthographic size in orthographic mode.

	public Text altitude, azimuth;				// show anlge x, y of the camera

    private Touch initTouch = new Touch();
    public Camera cam;

	public float currentX = 0f;
    public float currentY = 0f;
    private Vector3 origRot;
	//bool touchFromAngle = false;


	bool gotoPie = false;


    public float rotSpeed = 0.05f;
    public float direction = -1;


	//To Icon of NearPie
	private Memory aMemory;
	public static Memory memoryToOpen;
	public GameObject nearPieButton;
	public GameObject nearPieColor;
	public static int indexOfmemList;



    // Use this for initialization
    void Start ()
    {
        origRot = cam.transform.eulerAngles;
        currentX = origRot.x; 
        currentY = origRot.y;
		nearPieButton.SetActive (false);

    }
	
	// Update is called once per frame
	void FixedUpdate () {
		azimuth.text = cam.transform.eulerAngles.y.ToString();
		altitude.text = cam.transform.eulerAngles.x.ToString();
		if (Input.touchCount == 1) {

			foreach (Touch touch in Input.touches) {
				if (touch.phase == TouchPhase.Began) {
					initTouch = touch;
				} else if (touch.phase == TouchPhase.Moved) {
					//swiping
					float deltaX = initTouch.position.x - touch.position.x;		//touch에 대한, 따라서 x는 앵글에서는 Azimuth가 되~ 그래서 currentY를 해~
					float deltaY = initTouch.position.y - touch.position.y;
					currentX += deltaY * Time.smoothDeltaTime * rotSpeed * direction;
					currentY -= deltaX * Time.smoothDeltaTime * rotSpeed * direction;
					currentX = Mathf.Clamp (currentX, -89f, 89f);
					cam.transform.eulerAngles = new Vector3 (currentX, currentY, 0f);
				} else if (touch.phase == TouchPhase.Ended) {
					initTouch = new Touch ();
				}

			}
		}
		if (Input.touchCount == 2) {
			// Store both touches.
			Touch touchZero = Input.GetTouch(0);
			Touch touchOne = Input.GetTouch(1);

			// Find the position in the previous frame of each touch.
			Vector2 touchZeroPrevPos = touchZero.position - touchZero.deltaPosition;
			Vector2 touchOnePrevPos = touchOne.position - touchOne.deltaPosition;

			// Find the magnitude of the vector (the distance) between the touches in each frame.
			float prevTouchDeltaMag = (touchZeroPrevPos - touchOnePrevPos).magnitude;
			float touchDeltaMag = (touchZero.position - touchOne.position).magnitude;

			// Find the difference in the distances between each frame.
			float deltaMagnitudeDiff = prevTouchDeltaMag - touchDeltaMag;

			// If the camera is orthographic...
			if (cam.orthographic)
			{
				// ... change the orthographic size based on the change in distance between the touches.
				cam.orthographicSize += deltaMagnitudeDiff * orthoZoomSpeed;

				// Make sure the orthographic size never drops below zero.
				cam.orthographicSize = Mathf.Max(cam.orthographicSize, 5.0f);
			}
			else
			{
				// Otherwise change the field of view based on the change in distance between the touches.
				cam.fieldOfView += deltaMagnitudeDiff * perspectiveZoomSpeed;

				// Clamp the field of view to make sure it's between 0 and 180.
				cam.fieldOfView = Mathf.Clamp(cam.fieldOfView, 5.0f, 170.0f);
			}
		}



		//GotoPie Button part
		if (gotoPie == true) {
			currentX = cam.transform.eulerAngles.x;
			currentY = cam.transform.eulerAngles.y;
			currentX++;
			if (currentX > 359) {
				currentX = 0;
			}
			if (89 < currentX && currentX <91) {
				currentX = 90;
				gotoPie = false;
			}
			cam.transform.eulerAngles = new Vector3 (currentX, currentY, 0f);
		}


		//Check whether closer to mem
		for (int i = 0; i < InputMemController.memList.Count; i++) {
			
			aMemory = (Memory)InputMemController.memList [i];
			if ((Mathf.Abs(cam.transform.eulerAngles.y - aMemory.camY) < 20 
				|| Mathf.Abs(cam.transform.eulerAngles.y - aMemory.camY) > 340)
				&&(Mathf.Abs(cam.transform.eulerAngles.x - aMemory.camX) < 20
				|| Mathf.Abs(cam.transform.eulerAngles.x - aMemory.camX) > 340)) {
				memoryToOpen = aMemory;
				indexOfmemList = i;
				nearPieButton.SetActive (true);
				nearPieColor.GetComponent<Image>().color = new Color(aMemory.colorR, aMemory.colorG, aMemory.colorB, aMemory.colorA);
				break;
			}
			nearPieButton.SetActive (false);	
			nearPieColor.GetComponent<Image> ().color = new Color (0, 0, 0, 0);
		}


		//bydongwoo
		if(Application.platform == RuntimePlatform.Android)
		{
			if(Input.GetKey(KeyCode.Escape))
			{
				SaveAndLoad.Save();
				Application.Quit();
			}
		}
	}





	public void ClickGoPie(){
		gotoPie = true;
		//cam.transform.eulerAngles.x = new Vector3 (0f, 90f, 0f);
	}

	public void Clickto0(){
		SaveAndLoad.Save();
		SceneManager.LoadScene (0);
	}





}
