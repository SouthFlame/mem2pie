﻿using UnityEngine;
using System.Collections;

public class TextureChanger : MonoBehaviour {
	
	// Use this for initialization
	void Start () {
		this.GetComponent<MeshRenderer>().material.mainTexture = Gallerytest.galleryImage;
		this.GetComponent<MeshRenderer> ().material.mainTextureScale = new Vector2 (-1, 1);
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
