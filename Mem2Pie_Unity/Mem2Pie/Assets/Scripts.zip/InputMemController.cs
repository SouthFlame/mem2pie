﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

[System.Serializable]
public class Memory{
	public float camX, camY;
	public string titleToMem, contextToMem;
	public float colorR=0, colorG=0, colorB=0, colorA=0;

	public Memory(string title, string context, float x, float y, Color pastelcolor){
		titleToMem = title;
		contextToMem = context;
		camX = x;
		camY = y;
		colorR = pastelcolor.r;
		colorG = pastelcolor.g;
		colorB = pastelcolor.b;
		colorA = pastelcolor.a;
	}
}
	
public class InputMemController : MonoBehaviour {
	public static ArrayList memList = new ArrayList();
	public GameObject copyPie;
	private float x, y;
	public InputField inputTitle, inputContext;
	public Memory mem;
	public GameObject memoryBoard;
	public Color[] pastelColors;
	public Color aColor ;
	public Camera camMain;
	public ColorBlock coloBlo;
	private bool editButtFlag = false;
	private bool nearPieButtFlag = false;

	// Use this for initialization
	void Start () {
		memoryBoard.SetActive(false);
	}
	
	// Update is called once per frame
	void Update () {
		x = camMain.transform.eulerAngles.x;
		y = camMain.transform.eulerAngles.y;
//		textX.text = x.ToString();
//		textY.text = y.ToString();

	}

	public void ClicktoEnabled(){
		editButtFlag = true;
		inputTitle.placeholder.GetComponent<Text>().text = "Enter text less than 20 characters..";
		inputTitle.text = "";
		inputContext.placeholder.GetComponent<Text>().text = "Enter text less than 20 characters..";
		inputContext.text = "";
		aColor = pastelColors[Random.Range(0,pastelColors.Length)];
		aColor.a = 0.4f;
		coloBlo = inputTitle.colors;
		coloBlo.normalColor=aColor;

		inputTitle.colors = coloBlo;
		inputContext.colors = coloBlo;

		//파이에선 좀더 진게 해려구
		aColor.a = 0.7f;
	
		memoryBoard.SetActive (true);
	}

	public void ClicktoSave(){
		//Process to make pie

		if (editButtFlag == true) {
			mem = new Memory (inputTitle.text.ToString (), inputContext.text.ToString (), x, y, aColor);
			memList.Add (mem);
			copyPie.GetComponent<PieGraph> ().NewGraph (mem, 0.125f);
		}
		if (nearPieButtFlag == true) {
			GeneralController.memoryToOpen.titleToMem = inputTitle.text;
			GeneralController.memoryToOpen.contextToMem = inputContext.text;
			memList [GeneralController.indexOfmemList] = GeneralController.memoryToOpen;
			copyPie.GetComponent<PieGraph> ().updatePie ();
		}

		//Flag초기화 및 메모리보드 안보이게 하기
		nearPieButtFlag = false;
		editButtFlag = false;
		memoryBoard.SetActive (false);
	}

	//nearPieButton이 액티브 되었을때
	public void ClicktoOpenMem(){
		nearPieButtFlag = true;
		inputTitle.text = GeneralController.memoryToOpen.titleToMem;
		inputContext.text = GeneralController.memoryToOpen.contextToMem;
		aColor = new Color(GeneralController.memoryToOpen.colorR, GeneralController.memoryToOpen.colorG
							, GeneralController.memoryToOpen.colorB, GeneralController.memoryToOpen.colorA);
		aColor.a = 0.4f;
		coloBlo = inputTitle.colors;
		coloBlo.normalColor = aColor;

		inputTitle.colors = coloBlo;
		inputContext.colors = coloBlo;

		memoryBoard.SetActive (true);
	}





}

