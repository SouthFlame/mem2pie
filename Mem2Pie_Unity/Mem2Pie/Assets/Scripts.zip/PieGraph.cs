﻿using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using System.Collections;
using System.Collections.Generic;
public class PieGraph : MonoBehaviour {
    public Image wedgePrefab;
	public List<GameObject> arrNewWedge = new List<GameObject>();
	private Memory aMemory;
	public GameObject cam;
	float x,y;
	float moveX, moveY;
	int direction = 1;
	bool moveCamFlag = false;


	//1. 카메라 각도
	//public GameObject cam2;
	Vector3 MainCamera;
	//2. target 각도
	//   - euler로 조절
	public Vector3 eulerTarget;
	Quaternion target;
	//   - 속도 설정
	float thetaY, thetaX;
	public float dir;//두 점 사이 거리
	public float FIRST_SPEED=30f;
	public float HIGH_SPEED=100f;
	public float LOW_SPEED=30f;
	public float FAST_DE=10f;
	public float LOW_DE=5f;
	public float LOW_DISTANCE = 30f;
	float [] DISTANCE=new float[]{360f,60f,30f,10f};
	float[] SPEED = new float[]{300f,200f,100f,30f ,10f};
	public float speed;

	void Start () {
	for (int i = 0; i < InputMemController.memList.Count; i++) {
		aMemory = (Memory)InputMemController.memList [i];
		NewGraph (aMemory, 0.125f);
		}
	}
	public void updatePie() {

		for (int i = 0; i <arrNewWedge.Count; i++) {
			
			GameObject.Destroy(arrNewWedge [i]);
			//arrNewWedge.RemoveAt (i);
		}
		for (int i = 0; i < InputMemController.memList.Count; i++) {


			aMemory = (Memory)InputMemController.memList [i];

			NewGraph (aMemory, 0.125f);
		}
	}
	//Move camera angle by click wedge button
	void Update () {
		if (moveCamFlag == true) {
			eulerTarget = new Vector3 (moveX, moveY, 0f);
			MainCamera = cam.transform.rotation.eulerAngles;

			if (eulerTarget.x > 90 && eulerTarget.x < 270) {
				eulerTarget.x = 180 - eulerTarget.x;
				eulerTarget.y += 180;
			}

			target.eulerAngles = eulerTarget;

			//두 점 사이 거리
			dir=(MainCamera-eulerTarget).magnitude;
			thetaY = Mathf.Abs (MainCamera.y - eulerTarget.y);
			if (thetaY > 180) {
				thetaY = 360 - thetaY;
			}
			thetaX = Mathf.Abs (MainCamera.x - eulerTarget.x);
			if (thetaX > 180) {
				thetaX = 360 - thetaX;
			}

			//rotation -y direction is error cause dir is increasing
//			if(dir>yy_){
//				target.y += 360;
//			}
//			yy_ = dir;
			if (dir <= 0.5) {
				speed = SPEED[0];
				moveCamFlag = false;
			}



			//   - 두 점 이동시 빠르게->느리게 (dir:0~50-->low, dir:50~-->high)
			if (thetaY+thetaX>DISTANCE[0]) {
				speed = SPEED [0];
			} else if (thetaY+thetaX>DISTANCE[1]) {
				speed = SPEED [1];
			} else if (thetaY+thetaX > DISTANCE [2]) {
				speed = SPEED [2];
			} else if (thetaY+thetaX > DISTANCE [3]) {
				speed = SPEED [3];
			} else {
				speed = SPEED [4];
			}
//			if (dir > LOW_DISTANCE) {
//				speed -= FAST_DE;
//				if (speed < HIGH_SPEED) {
//					speed = HIGH_SPEED;
//				}
//			} else {
//				speed -= LOW_DE;
//				if (speed < LOW_SPEED) {
//					speed = LOW_SPEED;
//				}
//			}

			print ("speed--->"+speed);


			//3. 회전

			cam.transform.rotation=Quaternion.RotateTowards(cam.transform.rotation,target,speed*Time.deltaTime);

		}

//		if (moveCamFlag == true) {
//			x = cam.transform.eulerAngles.x;
//			y = cam.transform.eulerAngles.y;
//			if (moveY - 1 < y && y < moveY + 1) {
//				y = moveY;
//			}else{
//				if (Mathf.Abs(moveY - y) > 180) {
//					direction = -1;
//				}
//				y = y  + (direction * 0.08f * Mathf.Abs(moveY - y));
//			}
//			if (moveX - 1 < x && x < moveX + 1) {
//				x = moveX;
//			} else {
//				if (x < 1) {
//					x = 359;
//				}
//				x = x - 0.06f * Mathf.Abs(moveX-x);
//			}
//
//			if (x == moveX && y == moveY) {
//				moveCamFlag = false;
//				direction = 1;
//			}
//			cam.transform.eulerAngles = new Vector3 (x, y, 0f);
//		}

	}
	/*
    void MakeGraph()
    {
        float total = 0f;
        float zRotation = 0f;
        for (int i = 0; i< values.Length; i++)
        {
            total += values[i];
        }

        for (int i = 0; i < values.Length; i++)
        {
            Image newWedge = Instantiate(wedgePrefab) as Image;
            newWedge.transform.SetParent(transform, false);
            newWedge.color = wedgeColors[i];
			newWedge.fillAmount = values[i] / total;
            newWedge.transform.rotation = Quaternion.Euler(new Vector3(90f, 0f, zRotation));
            zRotation -= newWedge.fillAmount * 360f;
		
            //button[i].image = newWedge;
           // button[i].transform.rotation = newWedge.transform.rotation;
       }

    }
    */

	public void NewGraph(Memory mem, float fillAmount)
	{  
		//Make Pie Image



		GameObject newButtonObj = new GameObject ("Button" + mem.camY);
		newButtonObj.transform.SetParent(transform, false);
		//newButtonObj.transform.position = new Vector3(0f,-290f,0f);
		newButtonObj.transform.rotation = Quaternion.Euler(new Vector3(90f, 0f, -(mem.camY)));
		newButtonObj.layer = 5;		// UI Layer
		Button newButton = newButtonObj.AddComponent<Button> ();
		CanvasRenderer canvasButton = newButtonObj.AddComponent<CanvasRenderer> ();
		RectTransform recTransButton = newButtonObj.AddComponent<RectTransform> ();
		Image imageButton = newButtonObj.AddComponent<Image> ();
		recTransButton.pivot = new Vector2(0.5f,-0.5f);
		recTransButton.sizeDelta = new Vector2 (40f,120f);
		newButton.targetGraphic = imageButton;
		imageButton.color = new Color (0,0,0,0);
		arrNewWedge.Add(newButtonObj);

		Image newWedge=Instantiate(wedgePrefab) as Image;
		newWedge.transform.SetParent(newButtonObj.transform, false);
		newWedge.color = new Color(mem.colorR,mem.colorG,mem.colorB,mem.colorA);
		newWedge.fillAmount = fillAmount;

		newWedge.transform.position = new Vector3(0f,-100f,0f);
		newWedge.transform.rotation = Quaternion.Euler(new Vector3(90f, 0f, -(mem.camY-fillAmount*180)));




		GameObject newTextObj = new GameObject ("Text");
		Text newText = newTextObj.AddComponent<Text>();
		newText.transform.SetParent (newButtonObj.transform, false);
		newText.text = mem.titleToMem;
		Font ArialFont = (Font)Resources.GetBuiltinResource(typeof(Font), "Arial.ttf");
		newText.font = ArialFont;
		newText.alignment = TextAnchor.MiddleCenter;
		newText.material = ArialFont.material;
		newText.color =new Color(0.125f,0.125f,0.125f,1);
		newText.rectTransform.Rotate(new Vector3(0f,0f,90f));
		newText.transform.SetParent(newButton.transform, true);
		newText.rectTransform.sizeDelta = new Vector2 (100f,30f);
		newText.lineSpacing = 1f;
		newButton.onClick.AddListener(delegate(){this.MoveCam(mem.camX,mem.camY);});

	}
	public void MoveCam (float x, float y) {
		moveX = x;
		moveY = y;
		moveCamFlag = true;
	}

//	public void InitializedForTouch(){
//	}

	
}
